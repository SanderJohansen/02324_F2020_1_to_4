public interface IShowStak {
		public void show();
}
