public interface IStak {
	public void push(String e);
	public String pop();
	public boolean tom();
	public boolean fuld(); 
	public void vis();
	public void show();
}


